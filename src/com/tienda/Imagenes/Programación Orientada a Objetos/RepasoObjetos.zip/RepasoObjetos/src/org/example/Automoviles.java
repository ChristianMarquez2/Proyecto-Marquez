package org.example;

public class Automoviles {
    String marca;
    Float cilindraje;
    String color;
    Double kilometraje;
    String FEnergia;

    public Automoviles() {
    }

    public Automoviles(String marca, Float cilindraje, String color, Double kilometraje, String FEnergia) {
        this.marca = marca;
        this.cilindraje = cilindraje;
        this.color = color;
        this.kilometraje = kilometraje;
        this.FEnergia = FEnergia;
    }
}
