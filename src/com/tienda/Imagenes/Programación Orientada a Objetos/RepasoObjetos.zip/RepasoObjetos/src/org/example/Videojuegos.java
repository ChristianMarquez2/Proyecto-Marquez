package org.example;

public class Videojuegos {
    String nombre;
    String Genero;
    int Restriccion;
    float precio;
    String Plataforma;

    public Videojuegos() {
    }

    public Videojuegos(String nombre, String genero, int restriccion, float precio, String plataforma) {
        this.nombre = nombre;
        Genero = genero;
        Restriccion = restriccion;
        this.precio = precio;
        Plataforma = plataforma;
    }
}
