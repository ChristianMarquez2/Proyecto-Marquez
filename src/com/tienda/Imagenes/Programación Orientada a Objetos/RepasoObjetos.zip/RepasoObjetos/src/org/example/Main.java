package org.example;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        InstrumentosMusicales bajo = new InstrumentosMusicales(
                "Cuerdas", "Bajo", "Roble", 400.0, 0.75
        );
        InstrumentosMusicales Piano = new InstrumentosMusicales(
                "Cuerdas", "Piano", "Roble", 600.0, 1.5
        );
        bajo.sonar();
        bajo.entretener();
        //Piano.sonar();
        //Piano.entretener();

        System.out.println(bajo.getCategoria());
        System.out.println(bajo.getNombre());
        Scanner entrada = new Scanner(System.in);
        String cuerdas = entrada.nextLine();
        System.out.println(Piano.getCategoria());
        System.out.println(Piano.getNombre());





        Deportes natacion = new Deportes(
                true, 7, "Natacion",  true, 32.0
        );
        Canciones cancion = new Canciones(
                "Suerte", "Pop", (int) 3.34, "Morat", "Español"
        );
        Automoviles automoviles = new Automoviles(
          "KIA", 1.248F, "Negro", 0.0, "Electrico"
        );
        Videojuegos videojuego = new Videojuegos(
                "God of war", "Accion", 14, 53, "Playstation"
        );

    }
}