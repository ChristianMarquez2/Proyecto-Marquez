package org.example;

public class Canciones {
    String nombre;
    String genero;
    int duracion;
    String autor;
    String Idioma;

    public Canciones() {
    }

    public Canciones(String nombre, String genero, int duracion, String autor, String idioma) {
        this.nombre = nombre;
        this.genero = genero;
        this.duracion = duracion;
        this.autor = autor;
        Idioma = idioma;
    }
}
