package org.example;
public class Deportes {
    String nombre;
    int jugadores;
    Boolean asociado;
    Boolean olimpico;
    Double duracion;
    public Deportes() {
    }

    public Deportes(Boolean asociado, int jugadores, String nombre, Boolean olimpico, Double duracion) {
        this.asociado = asociado;
        this.jugadores = jugadores;
        this.nombre = nombre;
        this.olimpico = olimpico;
        this.duracion = duracion;
    }
}
