package org.example;

public class Libro {
    String nombre;
    String genero;
    boolean Indice;
    String Idioma;
    int precio;
    String autor;
    boolean Dedicatoria;
    String editorial;
    int NumerodePag;
    boolean Glosario;

    public Libro() {
    }

    public Libro(String nombre, String genero, boolean indice, String idioma, int precio, String autor, boolean dedicatoria, String editorial, int numerodePag, boolean glosario) {
        this.nombre = nombre;
        this.genero = genero;
        this.Indice = indice;
        this.Idioma = idioma;
        this.precio = precio;
        this.autor = autor;
        this.Dedicatoria = dedicatoria;
        this.editorial = editorial;
        this.NumerodePag = numerodePag;
        this.Glosario = glosario;
    }

    public Boolean reflexionar(){
        //Una funcion que me permite saber si entretiene o no
        return true;
    }
    public Boolean desear(){
        return true;
    }

    public Boolean asustar(){
        return true;
    }

    public Boolean recomendar(){
        return true;
    }

//gettes

    public String getNombre() {
        return nombre;
    }

    public String getGenero() {
        return genero;
    }

    public boolean isIndice() {
        return Indice;
    }

    public String getIdioma() {
        return Idioma;
    }

    public int getPrecio() {
        return precio;
    }

    public String getAutor() {
        return autor;
    }

    public boolean isDedicatoria() {
        return Dedicatoria;
    }

    public int getNumerodePag() {
        return NumerodePag;
    }

    public String getEditorial() {
        return editorial;
    }

    public boolean isGlosario() {
        return Glosario;
    }

    //settes


    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public void setIndice(boolean indice) {
        Indice = indice;
    }

    public void setIdioma(String idioma) {
        Idioma = idioma;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public void setDedicatoria(boolean dedicatoria) {
        Dedicatoria = dedicatoria;
    }

    public void setEditorial(String editorial) {
        this.editorial = editorial;
    }

    public void setNumerodePag(int numerodePag) {
        NumerodePag = numerodePag;
    }

    public void setGlosario(boolean glosario) {
        Glosario = glosario;
    }
}
