package org.example;

public class Videojuego {
    String nombre;
    String plataforma;
    String genero;
    String Desarrollador;
    int AñodeLanzamiento;
    String clasificacion;
    double precio;
    String jugadores;
    boolean disponible;
    boolean online;

    public Videojuego() {
    }

    public Videojuego(String nombre, String genero, String plataforma, String desarrollador, int añodeLanzamiento, String clasificacion, double precio, String jugadores, boolean disponible, boolean online) {
        this.nombre = nombre;
        this.genero = genero;
        this.plataforma = plataforma;
        Desarrollador = desarrollador;
        AñodeLanzamiento = añodeLanzamiento;
        this.clasificacion = clasificacion;
        this.precio = precio;
        this.jugadores = jugadores;
        this.disponible = disponible;
        this.online = online;
    }

    //Metodos
    public Boolean estretener(){
        //Una funcion que me permite saber si entretiene o no
        return true;
    }
    public Boolean estresar(){
        return true;
    }

    public Boolean asustar(){
        return true;
    }

    public Boolean recomendar(){
        return true;
    }

    public Videojuego(String nombre, String genero, String precio, String s, int i, String adulto, double v, boolean b) {
    }

    //getters
    public String getNombre() {
        return nombre;
    }

    public String getPlataforma() {
        return plataforma;
    }

    public String getGenero() {
        return genero;
    }

    public String getDesarrollador() {
        return Desarrollador;
    }

    public int getAñodeLanzamiento() {
        return AñodeLanzamiento;
    }

    public String getClasificacion() {
        return clasificacion;
    }

    public double getPrecio() {
        return precio;
    }

    public String getJugadores() {
        return jugadores;
    }

    public boolean isDisponible() {
        return disponible;
    }

    public boolean isOnline() {
        return online;
    }

    //setters

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setPlataforma(String plataforma) {
        this.plataforma = plataforma;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public void setDesarrollador(String desarrollador) {
        Desarrollador = desarrollador;
    }

    public void setAñodeLanzamiento(int añodeLanzamiento) {
        AñodeLanzamiento = añodeLanzamiento;
    }

    public void setClasificacion(String clasificacion) {
        this.clasificacion = clasificacion;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public void setJugadores(String jugadores) {
        this.jugadores = jugadores;
    }

    public void setDisponible(boolean disponible) {
        this.disponible = disponible;
    }

    public void setOnline(boolean online) {
        this.online = online;
    }
}
