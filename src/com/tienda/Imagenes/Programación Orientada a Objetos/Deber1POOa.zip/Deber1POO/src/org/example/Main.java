package org.example;
import java.util.Scanner;

public class Main {
    public Main() {
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Videojuego godOfWar = new Videojuego("God of War", "Santa Monica Studio", "Acción", "PlayStation 4", 2018, "Adulto", 39.99, "multijugador", true,true );
        Videojuego genshin = new Videojuego("Genshin Impact", "miHoYo", "Acción", "PC", 2020, "Jóvenes", 0.0, "multijugador",true,true);
        Videojuego mortal = new Videojuego("Mortal Kombat 11", "NetherRealm Studios", "Lucha", "PC", 2019, "Jóvenes", 19.99, "multijugador", true,true);
        Videojuego hitman = new Videojuego("Hitman 3", "IO Interactive", "Acción", "PC", 2021, "Jóvenes", 59.99, "multijugador", true,true);
        Videojuego persia = new Videojuego("Prince of Persia: Las Arenas del Tiempo", "Ubisoft", "Acción", "PC", 2003, "Jóvenes", 9.99, "multijugador", true,true);

        Libro patasArriba = new Libro("Patas Arriba", "Novela", true, "Español", 25, "Maria Fernanda Heredia", true, "LOQUELEO", 136, true);
        Libro demian = new Libro("Demian", "Novela", true, "Español", 5, "Hermann Hesse", true, "Panther", 107, true);
        Libro lunaNomada = new Libro("La luna Nómada", "Cuentos", true, "Español", 17, "Leonardo Vlencia", true, "LOQUELEO", 191, false);
        Libro Mitre = new Libro("Las sombras de la casa Mitre", "Novela", true, "Español", 14, "Ney Yépez Cortés", true, "ESKELETRA", 225, false);
        Libro amor = new Libro("Amor y otras palabras extrañas", "Novela", false, "Español", 24, "Erin Mccahan", false, "DEBOLS!LLO", 325, false);



        // Llamadas a métodos
        godOfWar.estretener();
        genshin.estresar();
        mortal.recomendar();
        hitman.asustar();

        Mitre.asustar();
        amor.desear();
        patasArriba.reflexionar();
        demian.recomendar();

    }
}

